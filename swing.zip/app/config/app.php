<?php
return [
    'host'  =>  "127.0.0.1",
    'port'  =>  "",
    'name'  =>  "swing",
    'user'  =>  "root",
    'pass'  =>  "app@123.",
    'type'  =>  "mysql",
    'prep'  =>  "1"
];
